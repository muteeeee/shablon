﻿using pr_22_106_01.Model;
using System;
using System.Linq;
using System.Windows;

namespace pr_22_106_01
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        // Загрузка данных из базы
        private void LoadData()
        {
            using (var context = new Model1())
            {
                // Загружаем все данные из таблицы Employees
                UsersDataGrid.ItemsSource = context.Employees.ToList();
            }
        }

        // Метод для добавления данных
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var employeesList = UsersDataGrid.ItemsSource as System.Collections.ObjectModel.ObservableCollection<Employees>;

            if (employeesList != null)
            {
                using (var context = new Model1())
                {
                    foreach (var employee in employeesList)
                    {
                        // Если сотрудник с таким телефоном еще не существует, добавляем его
                        if (context.Employees.All(ex => ex.Phone_num != employee.Phone_num))
                        {
                            context.Employees.Add(employee);
                        }
                    }
                    context.SaveChanges();
                }
            }
            LoadData();
        }

        // Метод для удаления данных
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedEmployee = UsersDataGrid.SelectedItem as Employees;

            if (selectedEmployee != null)
            {
                using (var context = new Model1())
                {
                    var employeeToDelete = context.Employees.FirstOrDefault(ex => ex.id == selectedEmployee.id);

                    if (employeeToDelete != null)
                    {
                        context.Employees.Remove(employeeToDelete);
                        context.SaveChanges();
                    }
                    else
                    {
                        MessageBox.Show("Сотрудник не найден.");
                    }
                }

                LoadData();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для удаления.");
            }
        }

        private void UsersDataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {

        }
    }
}
