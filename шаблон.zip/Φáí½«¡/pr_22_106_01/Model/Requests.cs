namespace pr_22_106_01.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Requests
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Requests()
        {
            Comments = new HashSet<Comments>();
        }

        public int id { get; set; }

        public int idClient { get; set; }

        public int? idMaster { get; set; }

        public int id_TechType { get; set; }

        [Required]
        [StringLength(60)]
        public string climateTechModel { get; set; }

        [Column(TypeName = "date")]
        public DateTime startDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? completionDate { get; set; }

        [Required]
        [StringLength(100)]
        public string problemDescryption { get; set; }

        [StringLength(50)]
        public string repairParts { get; set; }

        [Required]
        [StringLength(30)]
        public string requestStatus { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Comments> Comments { get; set; }

        public virtual Employees Employees { get; set; }

        public virtual Employees Employees1 { get; set; }

        public virtual Tech_type Tech_type { get; set; }
    }
}
