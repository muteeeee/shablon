namespace pr_22_106_01.Model
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Comments
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int id { get; set; }

        public int idRequest { get; set; }

        public int idMaster { get; set; }

        [StringLength(60)]
        public string message { get; set; }

        public virtual Employees Employees { get; set; }

        public virtual Requests Requests { get; set; }
    }
}
