using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace pr_22_106_01.Model
{
    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model11")
        {
        }

        public virtual DbSet<Accounts> Accounts { get; set; }
        public virtual DbSet<Comments> Comments { get; set; }
        public virtual DbSet<Employees> Employees { get; set; }
        public virtual DbSet<Requests> Requests { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }
        public virtual DbSet<Tech_type> Tech_type { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employees>()
                .HasMany(e => e.Accounts)
                .WithRequired(e => e.Employees)
                .HasForeignKey(e => e.idUser)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Employees>()
                .HasMany(e => e.Comments)
                .WithRequired(e => e.Employees)
                .HasForeignKey(e => e.idMaster)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Employees>()
                .HasMany(e => e.Requests)
                .WithRequired(e => e.Employees)
                .HasForeignKey(e => e.idClient)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Employees>()
                .HasMany(e => e.Requests1)
                .WithOptional(e => e.Employees1)
                .HasForeignKey(e => e.idMaster);

            modelBuilder.Entity<Requests>()
                .HasMany(e => e.Comments)
                .WithRequired(e => e.Requests)
                .HasForeignKey(e => e.idRequest)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Roles>()
                .HasMany(e => e.Employees)
                .WithRequired(e => e.Roles)
                .HasForeignKey(e => e.idRole)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Tech_type>()
                .HasMany(e => e.Requests)
                .WithRequired(e => e.Tech_type)
                .HasForeignKey(e => e.id_TechType)
                .WillCascadeOnDelete(false);
        }
    }
}
